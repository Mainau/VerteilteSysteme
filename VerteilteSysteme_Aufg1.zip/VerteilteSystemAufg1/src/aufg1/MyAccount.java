package aufg1;

public class MyAccount {
    private static int value;


    public MyAccount(){
        value=0;
    }
    public int getValue(){

            return value;
       }

    public void setValue(int value){

            this.value=value;

    }
}
