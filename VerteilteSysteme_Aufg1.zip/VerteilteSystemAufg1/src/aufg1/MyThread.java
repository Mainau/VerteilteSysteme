package aufg1;
import java.util.Random;

public class MyThread extends MyAccount implements Runnable{
    private static final int threadMax = 10;
    private static int runCount = 0;
    private Random random=new Random();
    private int change;
    private static final Object valueLock = new Object();

    public void run() {
        while (runCount++ < 100) {
            synchronized (valueLock) {
                change = random.nextInt(2) == 1 ? 1 : -1;
                System.out.print(runCount + ": " + Thread.currentThread().getName() + " " + getValue() + " + " + change + " = ");
                setValue(getValue() + change);

                System.out.println(getValue());
                try {
                    valueLock.notify();
                    valueLock.wait();
                }catch(Exception e){
                    e.getMessage();
                }
            }
        }



    }


    public static void main(String args[]) {
        Thread myThread;

        for (int i = 0; i < threadMax; i++) {
            myThread=new Thread(new MyThread());
            myThread.start();

        }
    }

}
