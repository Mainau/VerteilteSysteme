package aufg3;

import java.io.*;

public class MySerializer {
	private MySerializableClass mySerializableClass;

	MySerializer(MySerializableClass serializableClass) {
		mySerializableClass = serializableClass;
	}

	private String readFilename() throws IOException {
		String filename;
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.print("filename> ");
		filename = reader.readLine();

		return filename;
	}

	public void write(String text) throws IOException {
		mySerializableClass.set(text);
		String filename = "C:\\Users\\F\\workspace\\VerteilteSystemAufg1\\src\\aufg3\\"+readFilename();

		try {
			FileOutputStream fileOut = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(mySerializableClass);
			out.close();
			fileOut.close();
			System.out.printf("Serialisiert in " + filename);
		} catch (IOException i) {
			i.printStackTrace();
		}

	}

	public String read() throws IOException, ClassNotFoundException {
		String filename = "C:\\Users\\F\\workspace\\VerteilteSystemAufg1\\src\\aufg3\\"+readFilename();

		try {
			FileInputStream fileIn = new FileInputStream(filename);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			mySerializableClass = (MySerializableClass) in.readObject();
			in.close();
			fileIn.close();
		} catch (IOException i) {
			i.printStackTrace();

		} catch (ClassNotFoundException c) {
			System.out.println("Objekt nicht gefunden");
			c.printStackTrace();
		}

		return mySerializableClass.toString();
	}
}
